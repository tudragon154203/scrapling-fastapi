#!/bin/bash
set -euo pipefail
bun install