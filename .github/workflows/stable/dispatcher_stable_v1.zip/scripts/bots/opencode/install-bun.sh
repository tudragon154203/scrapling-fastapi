#!/bin/bash
set -euo pipefail
npm install -g bun