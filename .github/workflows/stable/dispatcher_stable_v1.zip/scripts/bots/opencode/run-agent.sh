#!/bin/bash
set -euo pipefail
bun "$RUNNER_DIR/index.ts"